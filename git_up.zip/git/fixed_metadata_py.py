from fastapi import APIRouter, HTTPException, BackgroundTasks, Depends
from pydantic import BaseModel
from typing import List, Optional, Dict, Any, Tuple
import uuid
import asyncio
import json
import os
import time
from datetime import datetime, timedelta
import pandas as pd
from io import StringIO
from openai import AsyncAzureOpenAI
import re
import tiktoken
import traceback
from collections import deque

# Updated constants for dual instance optimization
MAX_INPUT_TOKENS = 100000  
MAX_OUTPUT_TOKENS = 16000  
INSTRUCTION_TOKEN_RESERVE = 0.3  

# Rate limiting constants optimized for dual instances
MAX_REQUESTS_PER_MINUTE = 2700  # Per instance
MAX_TOKENS_PER_MINUTE = 450000  # Per instance

# Optimized concurrent requests for dual instances
MAX_CONCURRENT_REQUESTS_DUAL = 200  # Total across both instances (100 each)
MAX_CONCURRENT_REQUESTS_SINGLE = 50  # Conservative for single instance

MAX_ROWS_LIMIT = 20000  # Maximum rows to process

# Dynamic instance thresholds - Cost optimization
SINGLE_INSTANCE_THRESHOLD = 1000  # Use single instance for <= 1000 rows
DUAL_INSTANCE_THRESHOLD = 1001   # Use dual instances for > 1000 rows
ESTIMATED_PROCESSING_TIME_PER_ROW = 0.05  # seconds per row for single instance

# Retry configuration - Optimized for dual instances
MAX_RETRIES = 3  
RETRY_DELAYS = [2.0, 5.0, 10.0]  # Longer delays for stability

# Function to count tokens
def get_token_count(text: str) -> int:
    """Count the number of tokens in a text string using tiktoken"""
    try:
        encoder = tiktoken.encoding_for_model("gpt-4")
        return len(encoder.encode(text))
    except Exception:
        # Fallback estimation if tiktoken is not available
        return len(text) // 4  # Rough approximation: ~4 chars per token

def determine_instance_strategy(row_count: int) -> dict:
    """Determine the optimal instance strategy based on row count for cost optimization"""
    strategy = {
        "use_dual_instances": False,
        "primary_only": True,
        "estimated_time_minutes": 0,
        "reasoning": ""
    }
    
    if row_count <= SINGLE_INSTANCE_THRESHOLD:
        # Use single instance for smaller datasets
        strategy.update({
            "use_dual_instances": False,
            "primary_only": True,
            "estimated_time_minutes": (row_count * ESTIMATED_PROCESSING_TIME_PER_ROW) / 60,
            "reasoning": f"Using single instance for {row_count} rows (cost-effective for ≤{SINGLE_INSTANCE_THRESHOLD} rows)"
        })
    else:
        # Use dual instances for larger datasets
        strategy.update({
            "use_dual_instances": True,
            "primary_only": False,
            "estimated_time_minutes": (row_count * ESTIMATED_PROCESSING_TIME_PER_ROW) / 120,  # Roughly half time with 2 instances
            "reasoning": f"Using dual instances for {row_count} rows (optimal for >{SINGLE_INSTANCE_THRESHOLD} rows)"
        })
    
    return strategy

def get_optimal_batch_settings(instance_strategy: dict) -> dict:
    """Get optimal batch and concurrency settings based on instance strategy"""
    if instance_strategy["use_dual_instances"]:
        return {
            "concurrent_limit": MAX_CONCURRENT_REQUESTS_DUAL,  # 200 total
            "batch_size": 200,  # Process 200 rows per batch
            "timeout_base": 600,  # 10 minutes base timeout
            "timeout_per_row": 5,  # 5 seconds per row
            "delay_between_batches": 1.0,  # 1 second delay
            "requests_per_instance": 100,  # 100 requests per instance
            "description": "Dual instance mode: 200 concurrent (100 per instance)"
        }
    else:
        return {
            "concurrent_limit": MAX_CONCURRENT_REQUESTS_SINGLE,  # 50 total
            "batch_size": 50,  # Process 50 rows per batch
            "timeout_base": 300,  # 5 minutes base timeout
            "timeout_per_row": 8,  # 8 seconds per row (more conservative)
            "delay_between_batches": 2.0,  # 2 second delay
            "requests_per_instance": 50,  # All 50 on single instance
            "description": "Single instance mode: 50 concurrent"
        }

def get_instance_for_row(row_index: int, active_pool: list) -> tuple:
    """Get the best instance for a row based on load balancing"""
    if not active_pool or len(active_pool) == 0:
        raise ValueError("No active client pool available")
    
    if len(active_pool) == 1:
        return active_pool[0]
    
    # Round-robin load balancing
    instance_index = row_index % len(active_pool)
    selected_instance = active_pool[instance_index]
    
    # Validate the selected instance
    client, deployment, rate_limiter = selected_instance
    if client is None:
        # Fallback to first available client
        for instance in active_pool:
            if instance[0] is not None:
                return instance
        raise ValueError("No working clients available in pool")
    
    return selected_instance

def log_instance_usage(instance_strategy: dict, batch_info: dict):
    """Log instance usage for monitoring"""
    if instance_strategy["use_dual_instances"]:
        print(f"🔄 DUAL INSTANCE MODE:")
        print(f"   Total concurrent requests: {batch_info['concurrent_limit']}")
        print(f"   Requests per instance: ~{batch_info['concurrent_limit']//2}")
        print(f"   Batch size: {batch_info['batch_size']} rows")
        print(f"   Expected throughput: ~{batch_info['batch_size']/batch_info['timeout_per_row']} rows/second")
    else:
        print(f"🔧 SINGLE INSTANCE MODE:")
        print(f"   Total concurrent requests: {batch_info['concurrent_limit']}")
        print(f"   Batch size: {batch_info['batch_size']} rows") 
        print(f"   Expected throughput: ~{batch_info['batch_size']/batch_info['timeout_per_row']} rows/second")

class ImprovedRateLimiter:
    """Enhanced rate limiter with better handling for large datasets"""
    def __init__(self, max_requests_per_minute: int, max_tokens_per_minute: int, instance_name: str = "default"):
        self.max_requests_per_minute = max_requests_per_minute
        self.max_tokens_per_minute = max_tokens_per_minute
        self.instance_name = instance_name
        self.request_times = deque(maxlen=1000)  # FIXED: Prevent unlimited growth
        self.token_usage = deque(maxlen=1000)    # FIXED: Prevent unlimited growth
        self.lock = asyncio.Lock()
        self.consecutive_failures = 0
        self.last_failure_time = 0
    
    async def acquire(self, estimated_tokens: int = 500):
        """Acquire permission with exponential backoff on failures"""
        async with self.lock:
            now = time.time()
            minute_ago = now - 60
            
            # Clean old entries more efficiently
            while self.request_times and self.request_times[0] < minute_ago:
                self.request_times.popleft()
            while self.token_usage and self.token_usage[0][0] < minute_ago:
                self.token_usage.popleft()
            
            # Calculate current usage
            current_requests = len(self.request_times)
            current_tokens = sum(usage[1] for usage in self.token_usage)
            
            # More balanced thresholds for dual instance setup
            requests_threshold = int(self.max_requests_per_minute * 0.8)  # 80% utilization
            tokens_threshold = int(self.max_tokens_per_minute * 0.8)      # 80% utilization
            
            # Exponential backoff if we've had recent failures
            if self.consecutive_failures > 0:
                backoff_time = min(30, 2 ** self.consecutive_failures)  # Max 30 seconds
                if now - self.last_failure_time < backoff_time:
                    wait_time = backoff_time - (now - self.last_failure_time)
                    print(f"[{self.instance_name}] Exponential backoff: waiting {wait_time:.2f}s")
                    await asyncio.sleep(wait_time)
            
            # Check rate limits
            if current_requests >= requests_threshold or current_tokens + estimated_tokens > tokens_threshold:
                if current_requests >= requests_threshold and self.request_times:
                    wait_time = max(1.0, self.request_times[0] + 60 - now)
                elif current_tokens + estimated_tokens > tokens_threshold and self.token_usage:
                    wait_time = max(1.0, self.token_usage[0][0] + 60 - now)
                else:
                    wait_time = 1.0
                
                # Cap at reasonable maximum
                wait_time = min(wait_time, 60.0)  # Max 1 minute wait
                
                if wait_time > 0:
                    print(f"[{self.instance_name}] Rate limit reached. Waiting {wait_time:.2f}s")
                    await asyncio.sleep(wait_time)
            
            # Record this request
            self.request_times.append(now)
            self.token_usage.append((now, estimated_tokens))
    
    def record_success(self):
        """Reset failure counter on successful request"""
        self.consecutive_failures = 0
    
    def record_failure(self):
        """Increment failure counter and timestamp"""
        self.consecutive_failures += 1
        self.last_failure_time = time.time()

router = APIRouter(prefix="/metadata", tags=["metadata"])

# Storage for jobs - in production, this should be a database
jobs_storage: Dict[str, Any] = {}

# FIXED: Initialize clients with proper error handling and validation
client_1 = None
client_2 = None
deployment_1 = None
deployment_2 = None
rate_limiter_1 = None
rate_limiter_2 = None
client_pool = []

def initialize_openai_clients():
    """Initialize OpenAI clients with proper error handling"""
    global client_1, client_2, deployment_1, deployment_2, rate_limiter_1, rate_limiter_2, client_pool
    
    clients_initialized = []
    
    # Try to initialize primary instance
    try:
        client_1 = AsyncAzureOpenAI(
            api_key=os.getenv("AZURE_OPENAI_SERVICE_KEY"),
            azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
            api_version="2023-05-15"
        )
        deployment_1 = os.getenv("AZURE_OPENAI_DEPLOYMENT", "gpt-4o")
        rate_limiter_1 = ImprovedRateLimiter(MAX_REQUESTS_PER_MINUTE, MAX_TOKENS_PER_MINUTE, "Instance-1")
        clients_initialized.append("Instance-1")
        print(f"✅ Instance 1 initialized successfully: {deployment_1}")
    except Exception as e:
        print(f"❌ Failed to initialize Instance 1: {e}")
        client_1 = None
        deployment_1 = None
        rate_limiter_1 = None
    
    # Try to initialize secondary instance
    try:
        if os.getenv("AZURE_OPENAI_SERVICE_KEY_2") and os.getenv("AZURE_OPENAI_ENDPOINT_2"):
            client_2 = AsyncAzureOpenAI(
                api_key=os.getenv("AZURE_OPENAI_SERVICE_KEY_2"),
                azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT_2"),
                api_version="2023-05-15"
            )
            deployment_2 = os.getenv("AZURE_OPENAI_DEPLOYMENT_2", "gpt-4o")
            rate_limiter_2 = ImprovedRateLimiter(MAX_REQUESTS_PER_MINUTE, MAX_TOKENS_PER_MINUTE, "Instance-2")
            clients_initialized.append("Instance-2")
            print(f"✅ Instance 2 initialized successfully: {deployment_2}")
        else:
            print("⚠️ Instance 2 credentials not provided - will use single instance mode")
            client_2 = None
            deployment_2 = None
            rate_limiter_2 = None
    except Exception as e:
        print(f"❌ Failed to initialize Instance 2: {e}")
        client_2 = None
        deployment_2 = None
        rate_limiter_2 = None
    
    # Build client pool with only working clients
    client_pool = []
    if client_1 is not None:
        client_pool.append((client_1, deployment_1, rate_limiter_1))
    if client_2 is not None:
        client_pool.append((client_2, deployment_2, rate_limiter_2))
    
    if not client_pool:
        print("💥 CRITICAL: No OpenAI clients could be initialized!")
        print("Please check your Azure OpenAI credentials in environment variables:")
        print("- AZURE_OPENAI_SERVICE_KEY")
        print("- AZURE_OPENAI_ENDPOINT") 
        print("- AZURE_OPENAI_DEPLOYMENT")
        return False
    
    print(f"🚀 OpenAI client initialization complete: {len(client_pool)} instance(s) available")
    print(f"   Initialized: {', '.join(clients_initialized)}")
    return True

# Initialize clients on module load
openai_available = initialize_openai_clients()

# Global instance strategy tracking
current_instance_strategy = {
    "use_dual_instances": False,
    "primary_only": True,
    "active_client_pool": []
}

def setup_client_pool_for_strategy(strategy: dict) -> list:
    """Setup client pool based on the determined strategy with validation"""
    global current_instance_strategy
    
    if not client_pool:
        print("❌ No OpenAI clients available - cannot setup strategy")
        return []
    
    if strategy["use_dual_instances"] and len(client_pool) >= 2:
        # Use both instances if available
        active_pool = client_pool[:2]  # Use first 2 clients
        print(f"💰 Cost Optimization: Using DUAL instances for large dataset")
        print(f"   Expected time: ~{strategy['estimated_time_minutes']:.1f} minutes")
        print(f"   Reasoning: {strategy['reasoning']}")
    else:
        # Use only first available instance
        active_pool = [client_pool[0]]
        if strategy["use_dual_instances"] and len(client_pool) < 2:
            print(f"⚠️ Dual instance requested but only {len(client_pool)} available - using single instance")
        print(f"💰 Cost Optimization: Using SINGLE instance")
        print(f"   Expected time: ~{strategy['estimated_time_minutes']:.1f} minutes")
        print(f"   Reasoning: {strategy['reasoning']}")
    
    # Update global strategy
    current_instance_strategy.update(strategy)
    current_instance_strategy["active_client_pool"] = active_pool
    
    return active_pool

class MetadataField(BaseModel):
    name: str
    description: str
    isClassification: bool
    classificationOptions: Optional[List[str]] = None

class ExampleRow(BaseModel):
    text: str
    extracted_values: Dict[str, str]

class MetadataExtractionConfig(BaseModel):
    freeTextColumnIndex: int
    freeTextColumnName: Optional[str] = None
    freeTextColumnDescription: Optional[str] = ""
    metadataFields: List[MetadataField]
    exampleRows: Optional[List[int]] = []

class MetadataExtractionRequest(BaseModel):
    config: MetadataExtractionConfig
    csvData: List[Dict[str, Any]]

class MetadataFieldResult(BaseModel):
    value: str
    confidence: str  # "High", "Medium", or "Low"
    reason: str

class MetadataExtractionResult(BaseModel):
    rowIndex: int
    originalText: str
    extractedMetadata: Dict[str, MetadataFieldResult]

class ProcessingStats(BaseModel):
    total_rows: int
    total_time_seconds: float
    avg_time_per_row: float
    start_time: str
    end_time: str

class MetadataExtractionResponse(BaseModel):
    jobId: str
    status: str
    progress: int
    results: Optional[List[MetadataExtractionResult]] = None
    error: Optional[str] = None
    processing_stats: Optional[ProcessingStats] = None
    feedback: Optional[str] = None

class ReprocessRequest(BaseModel):
    rowIndices: List[int]

def create_error_result(row_index: int, row_data: Dict[str, Any], free_text_column: str, fields: List[MetadataField], error_message: str) -> MetadataExtractionResult:
    """Create an error result for a failed row"""
    metadata = {}
    for field in fields:
        metadata[field.name] = MetadataFieldResult(
            value="Error",
            confidence="Low",
            reason=f"Processing failed: {error_message}"
        )
    
    return MetadataExtractionResult(
        rowIndex=row_index,
        originalText=str(row_data.get(free_text_column, "")) if row_data else "",
        extractedMetadata=metadata
    )

async def extract_metadata_for_text_with_specific_instance(
    text: str,
    fields: List[MetadataField],
    column_description: str,
    client,
    deployment,
    rate_limiter,
    instance_name: str,
    row_index: int
) -> Dict[str, MetadataFieldResult]:
    """Extract metadata using a specific instance with tracking"""
    
    # Initialize results
    results = {}
    for field in fields:
        results[field.name] = MetadataFieldResult(
            value="Unknown",
            confidence="Low",
            reason="Initial placeholder"
        )
    
    # Validate client
    if client is None:
        for field in fields:
            results[field.name] = MetadataFieldResult(
                value="Error",
                confidence="Low",
                reason=f"{instance_name} client not available"
            )
        return results
    
    # Progressive timeouts for dual instance setup
    timeout_values = [60.0, 90.0, 120.0]
    retry_delays = [1.0, 3.0, 8.0]
    
    for attempt in range(MAX_RETRIES):
        try:
            timeout = timeout_values[min(attempt, len(timeout_values) - 1)]
            
            # Conservative token estimation
            estimated_tokens = get_token_count(text[:1000]) + len(fields) * 30 + 200
            
            # Acquire rate limit permission for this specific instance
            if rate_limiter:
                await rate_limiter.acquire(estimated_tokens)
            
            # Build messages
            messages = [
                {
                    "role": "system",
                    "content": """You are a metadata extraction assistant. Extract values for each requested field from the provided text.

IMPORTANT RULES:
- Return "unknown" if unsure about extraction
- Return "null" if field not present in text
- Always provide confidence (High/Medium/Low) and reason
- Be concise but accurate

Return JSON: {"field_name": {"value": "...", "confidence": "...", "reason": "..."}}"""
                },
                {
                    "role": "user",
                    "content": f"Text: {text}\n\nContext: {column_description}\n\nExtract these fields:\n"
                }
            ]
            
            # Add field instructions
            for field in fields:
                instruction = f"- {field.name}: {field.description}"
                if field.isClassification and field.classificationOptions:
                    instruction += f" (Options: {', '.join(field.classificationOptions)})"
                messages[-1]["content"] += instruction + "\n"
            
            # Make API call with instance tracking
            response = await asyncio.wait_for(
                client.chat.completions.create(
                    model=deployment,
                    messages=messages,
                    temperature=0.1,
                    max_tokens=800,
                ),
                timeout=timeout
            )
            
            response_content = response.choices[0].message.content
            
            # Parse response
            if response_content.strip().startswith("```"):
                response_content = re.sub(r"^```[a-zA-Z]*\n?", "", response_content.strip())
                response_content = re.sub(r"```$", "", response_content.strip())
            
            json_match = re.search(r'{[\s\S]*}', response_content)
            if json_match:
                response_content = json_match.group(0)
            
            extracted_data = json.loads(response_content)
            
            # Process results
            for field in fields:
                field_data = extracted_data.get(field.name, {})
                
                if isinstance(field_data, str):
                    field_data = {
                        "value": field_data,
                        "confidence": "Medium",
                        "reason": "Value extracted"
                    }
                
                value = field_data.get("value", "unknown")
                confidence = field_data.get("confidence", "Medium")
                reason = field_data.get("reason", "No reason provided")
                
                if confidence not in ["High", "Medium", "Low"]:
                    confidence = "Medium"
                
                if not value or value in ["", "Unable to extract", "Not found"]:
                    value = "null"
                    reason = "Field not found in text"
                    confidence = "Low"
                
                results[field.name] = MetadataFieldResult(
                    value=value,
                    confidence=confidence,
                    reason=reason
                )
            
            # Record success
            if rate_limiter:
                rate_limiter.record_success()
            return results
            
        except asyncio.TimeoutError:
            print(f"Row {row_index} timeout on {instance_name} (attempt {attempt + 1})")
            if rate_limiter:
                rate_limiter.record_failure()
            
            if attempt < MAX_RETRIES - 1:
                await asyncio.sleep(retry_delays[min(attempt, len(retry_delays) - 1)])
            else:
                for field in fields:
                    results[field.name] = MetadataFieldResult(
                        value="unknown",
                        confidence="Low",
                        reason=f"{instance_name} timeout after {MAX_RETRIES} attempts"
                    )
                return results
        
        except Exception as e:
            print(f"Row {row_index} error on {instance_name} (attempt {attempt + 1}): {str(e)}")
            if rate_limiter:
                rate_limiter.record_failure()
            
            if attempt < MAX_RETRIES - 1:
                await asyncio.sleep(retry_delays[min(attempt, len(retry_delays) - 1)])
            else:
                for field in fields:
                    results[field.name] = MetadataFieldResult(
                        value="unknown",
                        confidence="Low",
                        reason=f"{instance_name} error after {MAX_RETRIES} attempts: {str(e)}"
                    )
                return results
    
    return results

async def process_single_row_with_instance(
    row_index: int, 
    row_data: Dict[str, Any], 
    free_text_column: str, 
    fields: List[MetadataField], 
    column_description: str,
    client,
    deployment, 
    rate_limiter,
    instance_name: str
) -> MetadataExtractionResult:
    """Process single row with specific instance tracking"""
    try:
        text = str(row_data.get(free_text_column, "")).strip()
        
        if text:
            metadata = await extract_metadata_for_text_with_specific_instance(
                text,
                fields,
                column_description,
                client,
                deployment,
                rate_limiter,
                instance_name,
                row_index
            )
        else:
            metadata = {}
            for field in fields:
                metadata[field.name] = MetadataFieldResult(
                    value="null",
                    confidence="Low",
                    reason="No text provided"
                )
        
        return MetadataExtractionResult(
            rowIndex=row_index,
            originalText=text,
            extractedMetadata=metadata
        )
        
    except Exception as e:
        print(f"Error processing row {row_index} on {instance_name}: {str(e)}")
        return create_error_result(row_index, row_data, free_text_column, fields, f"{instance_name}: {str(e)}")

async def extract_metadata_for_text_with_retry(text: str, fields: List[MetadataField], column_description: str = "", examples: Optional[List[ExampleRow]] = None, row_index: int = -1) -> Dict[str, MetadataFieldResult]:
    """Extract metadata from a single text using OpenAI with retry logic and dynamic instance load balancing"""
    
    # Initialize results for all fields first
    results = {}
    for field in fields:
        results[field.name] = MetadataFieldResult(
            value="Unknown",
            confidence="Low",
            reason="Initial placeholder"
        )
    
    # FIXED: Check if OpenAI clients are available first
    if not openai_available or not client_pool:
        for field in fields:
            results[field.name] = MetadataFieldResult(
                value="OpenAI client not available",
                confidence="Low",
                reason="OpenAI clients could not be initialized"
            )
        return results

    # Validate input text
    if not text or not text.strip():
        for field in fields:
            results[field.name] = MetadataFieldResult(
                value="null",
                confidence="Low",
                reason="No text provided for extraction"
            )
        return results

    # Get active client pool
    active_pool = current_instance_strategy.get("active_client_pool", client_pool)
    
    # Ensure we have a valid active pool
    if not active_pool:
        active_pool = client_pool
    
    try:
        # Get instance for this row with validation
        client, deployment, rate_limiter = get_instance_for_row(row_index, active_pool)
        instance_name = rate_limiter.instance_name if rate_limiter and hasattr(rate_limiter, 'instance_name') else f"Instance-{row_index % 2 + 1}"
        
        return await extract_metadata_for_text_with_specific_instance(
            text, fields, column_description, client, deployment, rate_limiter, instance_name, row_index
        )
    except Exception as e:
        print(f"Error in extract_metadata_for_text_with_retry: {str(e)}")
        for field in fields:
            results[field.name] = MetadataFieldResult(
                value="Error",
                confidence="Low",
                reason=f"Error getting instance: {str(e)}"
            )
        return results

# Keep the original function name for backward compatibility
async def extract_metadata_for_text(text: str, fields: List[MetadataField], column_description: str = "", examples: Optional[List[ExampleRow]] = None) -> Dict[str, MetadataFieldResult]:
    """Extract metadata from a single text using OpenAI with combined extraction and confidence assessment"""
    return await extract_metadata_for_text_with_retry(text, fields, column_description, examples, -1)

async def generate_feedback_summary(results: List[MetadataExtractionResult], fields: List[MetadataField]) -> Optional[str]:
    """Generate user-friendly feedback based on confidence scores and reasons"""
    
    # FIXED: Validate client availability before using
    if not openai_available or not client_pool or not results:
        return None
    
    # Use the first available working client for feedback generation
    working_client = None
    working_deployment = None
    
    for client, deployment, _ in client_pool:
        if client is not None:
            working_client = client
            working_deployment = deployment
            break
    
    if not working_client:
        print("No working OpenAI client available for feedback generation")
        return None
    
    # Analyze confidence distribution
    total_extractions = len(results) * len(fields)
    if total_extractions == 0:
        return None
        
    low_confidence_count = 0
    medium_confidence_count = 0
    high_confidence_count = 0
    
    confidence_issues = []
    field_issues = {}
    
    # Collect statistics and issues
    for result in results:
        for field_name, field_result in result.extractedMetadata.items():
            confidence = field_result.confidence.lower()
            
            if confidence == "low":
                low_confidence_count += 1
                confidence_issues.append({
                    "field": field_name,
                    "reason": field_result.reason,
                    "text_sample": result.originalText[:100] + "..." if len(result.originalText) > 100 else result.originalText
                })
                
                if field_name not in field_issues:
                    field_issues[field_name] = {"low": 0, "medium": 0, "reasons": []}
                field_issues[field_name]["low"] += 1
                field_issues[field_name]["reasons"].append(field_result.reason)
                
            elif confidence == "medium":
                medium_confidence_count += 1
                if field_name not in field_issues:
                    field_issues[field_name] = {"low": 0, "medium": 0, "reasons": []}
                field_issues[field_name]["medium"] += 1
                field_issues[field_name]["reasons"].append(field_result.reason)
                
            elif confidence == "high":
                high_confidence_count += 1
    
    # Calculate percentages
    low_percentage = (low_confidence_count / total_extractions) * 100
    medium_percentage = (medium_confidence_count / total_extractions) * 100
    high_percentage = (high_confidence_count / total_extractions) * 100
    
    # Only generate feedback if there are medium or low confidence results
    if low_percentage < 5 and medium_percentage < 10:
        return None  # High accuracy, no feedback needed
    
    try:
        # Prepare field descriptions for context
        field_descriptions = "\n".join([f"- {field.name}: {field.description}" for field in fields])
        
        # Prepare common issues by field
        field_analysis = ""
        for field_name, issues in field_issues.items():
            if issues["low"] > 0 or issues["medium"] > 0:
                field_analysis += f"\nField '{field_name}':\n"
                field_analysis += f"  - Low confidence: {issues['low']} instances\n"
                field_analysis += f"  - Medium confidence: {issues['medium']} instances\n"
                
                # Get unique reasons
                unique_reasons = list(set(issues["reasons"]))
                field_analysis += f"  - Common issues: {', '.join(unique_reasons[:3])}\n"
        
        # Create prompt for feedback generation
        messages = [
            {
                "role": "system",
                "content": (
                    "You are a helpful assistant that provides actionable feedback for improving metadata extraction. "
                    "Based on the extraction statistics and common issues, provide clear, concise recommendations "
                    "in a user-friendly format. Focus on practical steps users can take to improve their results."
                )
            },
            {
                "role": "user",
                "content": f"""
Metadata Extraction Analysis:

Extraction Statistics:
- Total extractions: {total_extractions}
- High confidence: {high_confidence_count} ({high_percentage:.1f}%)
- Medium confidence: {medium_confidence_count} ({medium_percentage:.1f}%)
- Low confidence: {low_confidence_count} ({low_percentage:.1f}%)

Field Definitions:
{field_descriptions}

Field-Specific Issues:
{field_analysis}

Sample Issues:
{chr(10).join([f"- {issue['field']}: {issue['reason']}" for issue in confidence_issues[:5]])}

Please provide user-friendly feedback with specific steps to improve extraction accuracy. 
Format your response as actionable recommendations, focusing on:
1. Data quality improvements
2. Field definition clarity
3. Example enhancements
4. Text preprocessing suggestions

Keep the response concise but helpful (max 300 words).
Use plain text format without markdown symbols, headers, or asterisks for emphasis.
                """
            }
        ]
        
        feedback_response = await working_client.chat.completions.create(
            model=working_deployment,
            messages=messages,
            temperature=0.3,
            max_tokens=400,
        )
        
        feedback = feedback_response.choices[0].message.content.strip()
        
        # Clean up markdown formatting from the feedback
        import re
        # Remove markdown headers (# ## ### ####)
        feedback = re.sub(r'^#{1,6}\s*', '', feedback, flags=re.MULTILINE)
        # Remove bold/italic markers (**text** or *text*)
        feedback = re.sub(r'\*\*([^*]+)\*\*', r'\1', feedback)
        feedback = re.sub(r'\*([^*]+)\*', r'\1', feedback)
        # Clean up any remaining asterisks at the beginning of lines
        feedback = re.sub(r'^\*+\s*', '- ', feedback, flags=re.MULTILINE)
        # Clean up extra whitespace
        feedback = re.sub(r'\n\s*\n', '\n\n', feedback)
        feedback = feedback.strip()
        
        return feedback
        
    except Exception as e:
        print(f"Error generating feedback: {e}")
        return None

async def process_metadata_extraction(job_id: str, request: MetadataExtractionRequest):
    """
    Optimized metadata extraction for dual instances with 200 concurrent requests
    🚀 DUAL INSTANCE OPTIMIZATION: 200 concurrent (100 per instance)
    """
    try:
        # FIXED: Check OpenAI availability first
        if not openai_available:
            raise ValueError("OpenAI clients not available - check your Azure OpenAI credentials")
        
        start_time = datetime.now()
        jobs_storage[job_id]["status"] = "processing"
        jobs_storage[job_id]["progress"] = 0
        
        csv_data = request.csvData
        config = request.config
        
        if not csv_data:
            raise ValueError("No CSV data provided")
        
        # Handle row limits
        original_row_count = len(csv_data)
        if len(csv_data) > MAX_ROWS_LIMIT:
            print(f"Input has {len(csv_data)} rows, limiting to first {MAX_ROWS_LIMIT} rows")
            csv_data = csv_data[:MAX_ROWS_LIMIT]
        
        total_rows = len(csv_data)
        print(f"🚀 Starting optimized extraction of {total_rows} rows...")
        
        # Set up column information
        column_names = list(csv_data[0].keys())
        free_text_column = None
        
        if config.freeTextColumnName and config.freeTextColumnName in column_names:
            free_text_column = config.freeTextColumnName
        elif config.freeTextColumnIndex < len(column_names):
            free_text_column = column_names[config.freeTextColumnIndex]
        else:
            raise ValueError("Invalid column configuration")
        
        # 🚀 OPTIMIZATION: Determine instance strategy
        instance_strategy = determine_instance_strategy(total_rows)
        active_client_pool = setup_client_pool_for_strategy(instance_strategy)
        
        # FIXED: Validate we have working clients
        if not active_client_pool:
            raise ValueError("No working OpenAI clients available for processing")
        
        # 🚀 OPTIMIZATION: Get optimal batch settings
        batch_settings = get_optimal_batch_settings(instance_strategy)
        
        concurrent_limit = batch_settings["concurrent_limit"]
        batch_size = batch_settings["batch_size"] 
        timeout_base = batch_settings["timeout_base"]
        timeout_per_row = batch_settings["timeout_per_row"]
        delay_between_batches = batch_settings["delay_between_batches"]
        
        print(f"🔧 BATCH CONFIGURATION:")
        print(f"   {batch_settings['description']}")
        print(f"   Batch size: {batch_size} rows")
        print(f"   Concurrent limit: {concurrent_limit}")
        print(f"   Timeout: {timeout_base}s base + {timeout_per_row}s per row")
        print(f"   Available clients: {len(active_client_pool)}")
        
        # Log instance usage
        log_instance_usage(instance_strategy, batch_settings)
        
        # Create semaphore for concurrency control
        semaphore = asyncio.Semaphore(concurrent_limit)
        
        async def process_row_with_load_balancing(row_index: int, row_data: Dict[str, Any]) -> MetadataExtractionResult:
            """Process row with intelligent load balancing across instances"""
            async with semaphore:
                try:
                    # Get the best instance for this row
                    selected_instance = get_instance_for_row(row_index, active_client_pool)
                    client, deployment, rate_limiter = selected_instance
                    
                    # Track which instance we're using
                    instance_name = rate_limiter.instance_name if rate_limiter and hasattr(rate_limiter, 'instance_name') else f"Instance-{row_index % len(active_client_pool) + 1}"
                    
                    return await process_single_row_with_instance(
                        row_index, 
                        row_data, 
                        free_text_column, 
                        config.metadataFields, 
                        config.freeTextColumnDescription,
                        client,
                        deployment,
                        rate_limiter,
                        instance_name
                    )
                except Exception as e:
                    print(f"Row {row_index} failed in load balancing: {str(e)}")
                    return create_error_result(row_index, row_data, free_text_column, config.metadataFields, f"Load balancing error: {str(e)}")
        
        # Process with optimized batching
        results = []
        processed_count = 0
        error_count = 0
        total_batches = (total_rows + batch_size - 1) // batch_size
        
        print(f"📦 Processing {total_rows} rows in {total_batches} batches of {batch_size}")
        
        for batch_num in range(total_batches):
            batch_start = batch_num * batch_size
            batch_end = min(batch_start + batch_size, total_rows)
            batch_rows = csv_data[batch_start:batch_end]
            actual_batch_size = len(batch_rows)
            
            print(f"\n📦 Batch {batch_num + 1}/{total_batches}: Processing rows {batch_start}-{batch_end-1} ({actual_batch_size} rows)")
            
            batch_success = False
            batch_retry_count = 0
            max_batch_retries = 2
            
            while not batch_success and batch_retry_count < max_batch_retries:
                try:
                    # Create tasks for this batch
                    batch_tasks = []
                    for i, row in enumerate(batch_rows):
                        row_index = batch_start + i
                        task = process_row_with_load_balancing(row_index, row)
                        batch_tasks.append(task)
                    
                    # Calculate dynamic timeout based on actual batch size
                    batch_timeout = timeout_base + (actual_batch_size * timeout_per_row)
                    
                    print(f"⏱️  Starting batch with {len(batch_tasks)} tasks, timeout: {batch_timeout}s")
                    
                    # Execute batch with timeout
                    batch_start_time = time.time()
                    batch_results = await asyncio.wait_for(
                        asyncio.gather(*batch_tasks, return_exceptions=True),
                        timeout=batch_timeout
                    )
                    batch_duration = time.time() - batch_start_time
                    
                    # Process results
                    batch_errors = 0
                    batch_success_count = 0
                    
                    for i, result in enumerate(batch_results):
                        row_index = batch_start + i
                        
                        if isinstance(result, Exception):
                            print(f"❌ Row {row_index} exception: {str(result)[:100]}...")
                            error_result = create_error_result(
                                row_index, 
                                batch_rows[i], 
                                free_text_column, 
                                config.metadataFields, 
                                f"Exception: {str(result)}"
                            )
                            results.append(error_result)
                            batch_errors += 1
                        else:
                            results.append(result)
                            batch_success_count += 1
                    
                    batch_success = True
                    processed_count += batch_success_count
                    error_count += batch_errors
                    
                    # Batch completion stats
                    throughput = actual_batch_size / batch_duration if batch_duration > 0 else 0
                    print(f"✅ Batch {batch_num + 1} completed:")
                    print(f"   Duration: {batch_duration:.1f}s")
                    print(f"   Throughput: {throughput:.1f} rows/second")
                    print(f"   Success: {batch_success_count}, Errors: {batch_errors}")
                    
                except asyncio.TimeoutError:
                    batch_retry_count += 1
                    print(f"⏰ Batch {batch_num + 1} timeout (attempt {batch_retry_count}/{max_batch_retries})")
                    
                    if batch_retry_count < max_batch_retries:
                        print(f"🔄 Retrying batch after 30s delay...")
                        await asyncio.sleep(30)
                        # Reset results to start of this batch
                        results = results[:batch_start]
                        processed_count = len([r for r in results if not any(
                            field.value == "Error" for field in r.extractedMetadata.values()
                        )])
                        error_count = len(results) - processed_count
                    else:
                        print(f"❌ Batch {batch_num + 1} failed permanently - creating timeout errors")
                        for i, row in enumerate(batch_rows):
                            row_index = batch_start + i
                            error_result = create_error_result(
                                row_index, 
                                row, 
                                free_text_column, 
                                config.metadataFields, 
                                f"Batch {batch_num + 1} timeout after {max_batch_retries} attempts"
                            )
                            results.append(error_result)
                            error_count += 1
                        batch_success = True
                
                except Exception as e:
                    batch_retry_count += 1
                    print(f"❌ Batch {batch_num + 1} error (attempt {batch_retry_count}/{max_batch_retries}): {str(e)}")
                    
                    if batch_retry_count < max_batch_retries:
                        print(f"🔄 Retrying batch after 15s delay...")
                        await asyncio.sleep(15)
                        results = results[:batch_start]
                        processed_count = len([r for r in results if not any(
                            field.value == "Error" for field in r.extractedMetadata.values()
                        )])
                        error_count = len(results) - processed_count
                    else:
                        print(f"❌ Batch {batch_num + 1} failed permanently - creating error results")
                        for i, row in enumerate(batch_rows):
                            row_index = batch_start + i
                            error_result = create_error_result(
                                row_index, 
                                row, 
                                free_text_column, 
                                config.metadataFields, 
                                f"Batch {batch_num + 1} error: {str(e)}"
                            )
                            results.append(error_result)
                            error_count += 1
                        batch_success = True
            
            # Update progress
            progress = int((len(results) / total_rows) * 100)
            jobs_storage[job_id]["progress"] = progress
            jobs_storage[job_id]["last_update"] = datetime.now().isoformat()
            
            print(f"📊 Progress: {progress}% ({len(results)}/{total_rows} rows)")
            
            # Delay between batches for stability
            if batch_num + 1 < total_batches:
                print(f"⏸️  Waiting {delay_between_batches}s before next batch...")
                await asyncio.sleep(delay_between_batches)
        
        # Final processing
        end_time = datetime.now()
        processing_time = end_time - start_time
        total_seconds = processing_time.total_seconds()
        
        print(f"\n🎉 EXTRACTION COMPLETED!")
        print(f"📊 Final Statistics:")
        print(f"   Total time: {processing_time}")
        print(f"   Total rows processed: {len(results)}")
        print(f"   Successful extractions: {processed_count}")
        print(f"   Errors: {error_count}")
        print(f"   Overall throughput: {total_rows/total_seconds:.2f} rows/second")
        print(f"   Instance strategy: {instance_strategy['reasoning']}")
        
        # Generate feedback
        feedback = await generate_feedback_summary(results, config.metadataFields)
        
        # Complete job
        jobs_storage[job_id].update({
            "status": "completed",
            "results": results,
            "progress": 100,
            "last_update": end_time.isoformat(),
            "processing_stats": {
                "total_rows": total_rows,
                "processed_count": processed_count,
                "error_count": error_count,
                "total_time_seconds": total_seconds,
                "throughput_rows_per_second": total_rows/total_seconds if total_seconds > 0 else 0,
                "start_time": start_time.isoformat(),
                "end_time": end_time.isoformat(),
                "instance_strategy": instance_strategy,
                "batch_settings": batch_settings
            },
            "feedback": feedback
        })
        
        print(f"✅ Job {job_id} completed successfully with {len(results)} results")
        
    except Exception as e:
        print(f"💥 Critical error in job {job_id}: {str(e)}")
        traceback.print_exc()
        jobs_storage[job_id]["status"] = "error"
        jobs_storage[job_id]["error"] = str(e)
        jobs_storage[job_id]["last_update"] = datetime.now().isoformat()

@router.post("/extract", response_model=MetadataExtractionResponse)
async def start_metadata_extraction(request: MetadataExtractionRequest, background_tasks: BackgroundTasks):
    """Start a metadata extraction job"""
    # FIXED: Check OpenAI availability before starting job
    if not openai_available:
        raise HTTPException(
            status_code=503, 
            detail="OpenAI clients not available. Please check Azure OpenAI credentials."
        )
    
    job_id = str(uuid.uuid4())
    
    # Initialize job
    jobs_storage[job_id] = {
        "status": "pending",
        "progress": 0,
        "created_at": datetime.now(),
        "request": request.model_dump()
    }
    
    # Start background processing
    background_tasks.add_task(process_metadata_extraction, job_id, request)
    
    return MetadataExtractionResponse(
        jobId=job_id,
        status="pending",
        progress=0
    )

@router.get("/job/{job_id}", response_model=MetadataExtractionResponse)
async def get_job_status(job_id: str):
    """Get the status of a metadata extraction job"""
    if job_id not in jobs_storage:
        raise HTTPException(status_code=404, detail="Job not found")
    
    job = jobs_storage[job_id]
    
    return MetadataExtractionResponse(
        jobId=job_id,
        status=job["status"],
        progress=job["progress"],
        results=job.get("results"),
        error=job.get("error"),
        processing_stats=job.get("processing_stats"),
        feedback=job.get("feedback")
    )

@router.get("/health/{job_id}")
async def health_check(job_id: str):
    """Health check for long-running jobs"""
    if job_id not in jobs_storage:
        raise HTTPException(status_code=404, detail="Job not found")
    
    job = jobs_storage[job_id]
    
    return {
        "status": job["status"],
        "progress": job["progress"],
        "last_update": job.get("last_update", "unknown"),
        "processing_time": str(datetime.now() - job["created_at"]),
        "created_at": job["created_at"].isoformat() if isinstance(job["created_at"], datetime) else job["created_at"],
        "total_time_seconds": (datetime.now() - job["created_at"]).total_seconds() if isinstance(job["created_at"], datetime) else "unknown",
        "openai_available": openai_available,
        "active_clients": len(client_pool)
    }

@router.get("/download/{job_id}")
async def download_results(job_id: str):
    """Download the results as a CSV file"""
    if job_id not in jobs_storage:
        raise HTTPException(status_code=404, detail="Job not found")
    
    job = jobs_storage[job_id]
    if job["status"] != "completed":
        raise HTTPException(status_code=400, detail="Job not completed")
    
    results = job.get("results", [])
    if not results:
        raise HTTPException(status_code=404, detail="No results found")
    
    # Convert results to CSV with validation
    csv_data = []
    
    for result in results:
        row = {
            "Row Index": result.rowIndex,
            "Original Text": result.originalText
        }
        
        # Add metadata fields for this result
        for field_name, field_result in result.extractedMetadata.items():
            row[f"{field_name}"] = field_result.value
            row[f"{field_name} Confidence"] = field_result.confidence
            row[f"{field_name} Reason"] = field_result.reason
        
        csv_data.append(row)
    
    if csv_data:
        # Create and return the CSV
        df = pd.DataFrame(csv_data)
        csv_string = df.to_csv(index=False)
        
        from fastapi.responses import Response
        return Response(
            content=csv_string,
            media_type="text/csv",
            headers={"Content-Disposition": f"attachment; filename=metadata_extraction_{job_id}.csv"}
        )
    else:
        raise HTTPException(status_code=404, detail="No data to download")

@router.post("/reprocess/{job_id}", response_model=MetadataExtractionResponse)
async def reprocess_rows(job_id: str, request: ReprocessRequest, background_tasks: BackgroundTasks):
    """Reprocess specific rows of a completed job"""
    if not openai_available:
        raise HTTPException(
            status_code=503, 
            detail="OpenAI clients not available. Please check Azure OpenAI credentials."
        )
        
    if job_id not in jobs_storage:
        raise HTTPException(status_code=404, detail="Job not found")
    
    job = jobs_storage[job_id]
    if job["status"] != "completed":
        raise HTTPException(status_code=400, detail="Can only reprocess completed jobs")
    
    # Create new job for reprocessing
    new_job_id = str(uuid.uuid4())
    
    # Filter original data to only include specified rows
    original_request = job["request"]
    filtered_data = []
    for row_index in request.rowIndices:
        if row_index < len(original_request["csvData"]):
            filtered_data.append(original_request["csvData"][row_index])
    
    new_request = MetadataExtractionRequest(
        config=MetadataExtractionConfig(**original_request["config"]),
        csvData=filtered_data
    )
    
    # Initialize new job
    jobs_storage[new_job_id] = {
        "status": "pending",
        "progress": 0,
        "created_at": datetime.now(),
        "request": new_request.model_dump(),
        "parent_job": job_id
    }
    
    # Start background processing
    background_tasks.add_task(process_metadata_extraction, new_job_id, new_request)
    
    return MetadataExtractionResponse(
        jobId=new_job_id,
        status="pending",
        progress=0
    )

@router.get("/debug/{job_id}")
async def debug_job_results(job_id: str):
    """Debug endpoint to check the structure of job results"""
    if job_id not in jobs_storage:
        raise HTTPException(status_code=404, detail="Job not found")
    
    job = jobs_storage[job_id]
    results = job.get("results", [])
    
    debug_info = {
        "job_status": job["status"],
        "openai_available": openai_available,
        "client_pool_size": len(client_pool),
        "working_clients": len([c for c, _, _ in client_pool if c is not None]),
        "results_count": len(results)
    }
    
    if not results:
        return {"detail": "No results found", "debug_info": debug_info}
    
    # Return structure info about the first result
    sample_result = results[0]
    
    structure_info = {
        "result_type": str(type(sample_result)),
        "has_rowIndex": hasattr(sample_result, "rowIndex"),
        "has_originalText": hasattr(sample_result, "originalText"),
        "has_extractedMetadata": hasattr(sample_result, "extractedMetadata"),
    }
    
    if hasattr(sample_result, "extractedMetadata"):
        metadata = sample_result.extractedMetadata
        first_key = next(iter(metadata.keys()), None)
        
        if first_key:
            first_field = metadata[first_key]
            structure_info["metadata_field_type"] = str(type(first_field))
            structure_info["field_has_value"] = hasattr(first_field, "value")
            structure_info["field_has_confidence"] = hasattr(first_field, "confidence")
            structure_info["field_has_reason"] = hasattr(first_field, "reason")
    
    return {
        "structure_info": structure_info,
        "debug_info": debug_info,
        "sample_keys": dir(sample_result) if hasattr(sample_result, "__dict__") else [],
        "first_few_results": [r.model_dump() if hasattr(r, "model_dump") else r for r in results[:2]]
    }

# Health check endpoint for the router
@router.get("/health")
async def router_health():
    """Health check for the metadata router"""
    return {
        "status": "healthy",
        "openai_available": openai_available,
        "client_pool_size": len(client_pool),
        "working_clients": len([c for c, _, _ in client_pool if c is not None]),
        "dual_instance_capable": len(client_pool) >= 2
    }