# app/main.py - FIXED VERSION
from fastapi import FastAPI, HTTPException, UploadFile, File, Form, Request
from fastapi.staticfiles import StaticFiles
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from starlette.middleware.sessions import SessionMiddleware
from config import IS_READY, start_time, log
import uvicorn
import os
import json
import pandas as pd
import re
import asyncio
import uuid
import traceback
from io import StringIO, BytesIO
from datetime import datetime, timedelta
from typing import List
import time
from dotenv import load_dotenv
load_dotenv()
from redis.asyncio import Redis
from middleware.redis_session_middleware import RedisSessionMiddleware
from middleware.auth_required import AuthRequiredMiddleware

# Import database and storage
from cosmosdb import container, metadata_fields_container
from blobstorage import blob_container_client
from azure.cosmos import exceptions

# Import route modules
from routes.health import router as health_router
from routes.auth import router as auth_router
from routes.groups import router as groups_router
from routes.bots import router as bots_router
from routes.file import router as file_router
from routes.status import router as status_router
from routes.chat import router as chat_router
from routes.brd import router as brd_router
from routes.metadata import router as metadata_router
# FIXED: Import specific functions instead of trying to import all
from routes.metadata import (
    generate_feedback_summary, 
    MetadataExtractionResult, 
    MetadataFieldResult, 
    extract_metadata_for_text_with_retry, 
    MetadataField, 
    ExampleRow, 
    MAX_ROWS_LIMIT, 
    determine_instance_strategy, 
    setup_client_pool_for_strategy,
    get_optimal_batch_settings, 
    get_instance_for_row, 
    log_instance_usage
)
from routes.user_files import router as user_files_router

app = FastAPI(
    title="ENB Copilot Web API",
    description="A Python API to serve as Backend For the ENB Copilot Web App",
    version="0.1.0",
    docs_url="/docs",
)

# --- CORS Middleware ---
origins = [
    "http://localhost:5173",  # Frontend origin
]

# 1) Starlette's built-in SessionMiddleware (cookie-based fallback)
app.add_middleware(
    SessionMiddleware,
    secret_key="4224dd52-f701-47a4-9d9e-f7c4e1ca92b9",
    session_cookie="enb_session",
    max_age=86400,
)

# 2) Redis-backed Session Middleware
redis_client = Redis.from_url(os.getenv("REDIS_URL"), encoding="utf-8", decode_responses=True)
app.add_middleware(
    RedisSessionMiddleware,
    redis=redis_client,
)

# 3) CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- Include Routers ---
app.include_router(auth_router)
app.include_router(health_router)
app.include_router(groups_router)
app.include_router(bots_router)
app.include_router(file_router)
app.include_router(status_router)
app.include_router(chat_router)
app.include_router(brd_router)
app.include_router(metadata_router)
app.include_router(user_files_router)

# --- Root Redirect & Static Files ---
from fastapi.responses import RedirectResponse

@app.get("/api/history")
async def get_run_history(request: Request):
    """Get all run history for a user"""
    try:
        # Get user email from session/request
        user = getattr(request.state, "user", None)
        user_email = user.email if user and hasattr(user, "email") else None
        
        if not user_email:
            session = getattr(request.state, "session", {})
            user_profile = session.get("user")
            if user_profile:
                user_email = user_profile.get("mail") or user_profile.get("userPrincipalName")
                
        if not user_email:
            # Try getting from account info
            account = session.get("account") if session else None
            if account:
                user_email = account.get("preferred_username") or account.get("email") or account.get("upn")

        if not user_email:
            raise HTTPException(status_code=400, detail="User email not found")

        print(f"Fetching history for user: {user_email}")

        # Query Cosmos DB for all user's records
        query = f"SELECT * FROM c WHERE c.userEmail = '{user_email}'"
        items = list(container.query_items(query=query, enable_cross_partition_query=True))
        
        # Transform items to include only necessary information
        history_items = []
        for item in items:
            history_item = {
                "id": item["id"],
                "timestamp": item["timestamp"],
                "reportName": item.get("extractionReportName", "Untitled Report"),
                "uploadedFiles": [file["fileName"] for file in item.get("uploadedFiles", [])],
                "extractedFile": item.get("extractedFile", {}).get("fileName") if "extractedFile" in item else None,
                "numResults": len(item.get("extractedData", {}).get("tableData", [])) if "extractedData" in item else 0
            }
            history_items.append(history_item)
        
        # Sort by timestamp descending (newest first)
        history_items.sort(key=lambda x: x["timestamp"], reverse=True)
        
        return {
            "status": "success",
            "items": history_items
        }

    except Exception as e:
        print(f"Error getting run history: {str(e)}")
        print(f"Full traceback: {traceback.format_exc()}")
        raise HTTPException(status_code=500, detail=f"Failed to get run history: {str(e)}")

@app.delete("/api/history")
@app.delete("/api/metadata/history")
async def clear_run_history(request: Request):
    """Delete all run history for a user including files and metadata"""
    try:
        # Get request body for userEmail if provided
        try:
            body = await request.json()
            user_email_from_body = body.get("userEmail") if body else None
        except:
            user_email_from_body = None
        
        # Get user email from session/request or request body
        user = getattr(request.state, "user", None)
        user_email = user.email if user and hasattr(user, "email") else None
        
        if not user_email:
            session = getattr(request.state, "session", {})
            user_profile = session.get("user")
            if user_profile:
                user_email = user_profile.get("mail") or user_profile.get("userPrincipalName")
                
        if not user_email:
            # Try getting from account info
            account = session.get("account") if session else None
            if account:
                user_email = account.get("preferred_username") or account.get("email") or account.get("upn")

        # If still no user email, try to get it from request body
        if not user_email and user_email_from_body:
            user_email = user_email_from_body
            print(f"Got user email from request body: {user_email}")

        if not user_email:
            raise HTTPException(status_code=400, detail="User email not found")

        print(f"Starting deletion for user: {user_email}")

        # Query Cosmos DB for user's RUN HISTORY records only
        query = f"SELECT * FROM c WHERE c.userEmail = '{user_email}'"
        items = list(container.query_items(query=query, enable_cross_partition_query=True))
        print(f"Found {len(items)} run history records in Cosmos DB for user {user_email}")

        # Delete blobs from Azure Storage
        blob_paths_to_delete = set()
        for item in items:
            if "uploadedFiles" in item:
                for file_info in item["uploadedFiles"]:
                    if "blobPath" in file_info:
                        blob_paths_to_delete.add(file_info["blobPath"])
            
            if "extractedFile" in item and "blobPath" in item["extractedFile"]:
                blob_paths_to_delete.add(item["extractedFile"]["blobPath"])

        deleted_blobs = 0
        for blob_path in blob_paths_to_delete:
            try:
                blob_client = blob_container_client.get_blob_client(blob_path)
                if blob_client.exists():
                    blob_client.delete_blob(delete_snapshots="include")
                    deleted_blobs += 1
            except Exception as e:
                print(f"Failed to delete blob {blob_path}: {str(e)}")

        # Delete Cosmos DB records
        deleted_records = 0
        for item in items:
            try:
                container.delete_item(item=item["id"], partition_key=user_email)
                deleted_records += 1
            except Exception as e:
                print(f"Warning: Failed to delete Cosmos DB item {item['id']}: {str(e)}")

        return {
            "status": "success", 
            "message": f"Successfully deleted {deleted_records} run history records and {deleted_blobs} associated files.",
            "deletedRecords": deleted_records,
            "deletedFiles": deleted_blobs
        }

    except Exception as e:
        print(f"Error clearing run history: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to clear run history: {str(e)}")

@app.post("/api/metadata")
async def save_metadata_fields(request: Request):
    """Save metadata fields configuration for a user"""
    try:
        body = await request.json()
        
        # Get user email
        user = getattr(request.state, "user", None)
        user_email = user.email if user and hasattr(user, "email") else None
        
        if not user_email:
            session = getattr(request.state, "session", {})
            user_profile = session.get("user")
            if user_profile:
                user_email = user_profile.get("mail") or user_profile.get("userPrincipalName")

        if not user_email:
            user_email = body.get("userEmail")

        if not user_email:
            raise HTTPException(status_code=400, detail="User email not found")

        # Handle metadata configurations
        if "metadata" in body:
            metadata_content = body["metadata"]
            
            if isinstance(metadata_content, list):
                # Clear existing configurations
                query = f"SELECT c.id FROM c WHERE c.userEmail = '{user_email}'"
                existing_items = list(metadata_fields_container.query_items(query=query, enable_cross_partition_query=True))
                for item in existing_items:
                    metadata_fields_container.delete_item(item=item["id"], partition_key=user_email)
                
                # Save new configurations
                saved_configs = []
                for config in metadata_content:
                    if isinstance(config, dict) and "name" in config and "fieldsData" in config:
                        config_name = config["name"]
                        fields_data = config["fieldsData"]
                        
                        doc_id = str(uuid.uuid4())
                        doc = {
                            "id": doc_id,
                            "userEmail": user_email,
                            "timestamp": datetime.utcnow().isoformat(),
                            "configurationName": config_name,
                            "freeTextDescription": fields_data.get("freeTextDesc", ""),
                            "metadataFields": fields_data.get("metaDataFields", []),
                            "expectingTableOutput": {"tableData": True}
                        }
                        
                        metadata_fields_container.create_item(body=doc)
                        saved_configs.append({"id": doc_id, "name": config_name})
                
                return {
                    "status": "success",
                    "message": f"Successfully saved {len(saved_configs)} metadata configurations",
                    "configurations": saved_configs
                }

        return {"status": "success", "message": "Metadata saved successfully"}

    except Exception as e:
        print(f"Error saving metadata fields: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to save metadata fields: {str(e)}")

@app.get("/api/metadata")
async def get_metadata_fields(request: Request):
    """Get all saved metadata fields configurations for a user"""
    try:
        # Get user email
        user = getattr(request.state, "user", None)
        user_email = user.email if user and hasattr(user, "email") else None
        
        if not user_email:
            session = getattr(request.state, "session", {})
            user_profile = session.get("user")
            if user_profile:
                user_email = user_profile.get("mail") or user_profile.get("userPrincipalName")

        if not user_email:
            user_email = request.query_params.get("userEmail")

        if not user_email:
            raise HTTPException(status_code=400, detail="User email not found")

        # Query Cosmos DB
        query = f"SELECT * FROM c WHERE c.userEmail = '{user_email}'"
        items = list(metadata_fields_container.query_items(query=query, enable_cross_partition_query=True))
        
        configurations = []
        for item in items:
            first_field_name = "Long Description"
            if item.get("metadataFields") and len(item["metadataFields"]) > 0:
                first_field = item["metadataFields"][0]
                if isinstance(first_field, dict) and "name" in first_field:
                    first_field_name = first_field["name"]
            
            config = {
                "name": item.get("configurationName", "Default Configuration"),
                "id": item["id"],
                "fieldsData": {
                    "freeTextDesc": item.get("freeTextDescription", ""),
                    "freeTextColName": first_field_name,
                    "metaDataFields": item.get("metadataFields", []),
                    "lastUpdated": item["timestamp"],
                    "userEmail": user_email
                }
            }
            configurations.append(config)
        
        configurations.sort(key=lambda x: x["fieldsData"]["lastUpdated"], reverse=True)
        return configurations

    except Exception as e:
        print(f"Error getting metadata fields: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to get metadata fields: {str(e)}")

@app.get("/api/metadata/{config_id}")
async def get_metadata_fields_by_id(config_id: str, request: Request):
    """Get a specific metadata fields configuration by ID"""
    try:
        # Get user email
        user = getattr(request.state, "user", None)
        user_email = user.email if user and hasattr(user, "email") else None
        
        if not user_email:
            session = getattr(request.state, "session", {})
            user_profile = session.get("user")
            if user_profile:
                user_email = user_profile.get("mail") or user_profile.get("userPrincipalName")

        if not user_email:
            raise HTTPException(status_code=400, detail="User email not found")

        try:
            item = metadata_fields_container.read_item(item=config_id, partition_key=user_email)
            
            config = {
                "id": item["id"],
                "timestamp": item["timestamp"],
                "configurationName": item.get("configurationName", "Default Configuration"),
                "freeTextDescription": item["freeTextDescription"],
                "metadataFields": item["metadataFields"],
                "expectingTableOutput": item["expectingTableOutput"]
            }
            
            return {"status": "success", "configuration": config}
            
        except exceptions.CosmosResourceNotFoundError:
            raise HTTPException(status_code=404, detail="Configuration not found")

    except Exception as e:
        print(f"Error getting metadata fields by ID: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to get metadata fields: {str(e)}")

@app.delete("/api/metadata/{config_id}")
async def delete_metadata_fields(config_id: str, request: Request):
    """Delete a specific metadata fields configuration"""
    try:
        # Get user email
        user = getattr(request.state, "user", None)
        user_email = user.email if user and hasattr(user, "email") else None
        
        if not user_email:
            session = getattr(request.state, "session", {})
            user_profile = session.get("user")
            if user_profile:
                user_email = user_profile.get("mail") or user_profile.get("userPrincipalName")

        if not user_email:
            raise HTTPException(status_code=400, detail="User email not found")

        try:
            metadata_fields_container.delete_item(item=config_id, partition_key=user_email)
            return {"status": "success", "message": "Metadata fields configuration deleted successfully"}
            
        except exceptions.CosmosResourceNotFoundError:
            raise HTTPException(status_code=404, detail="Configuration not found")

    except Exception as e:
        print(f"Error deleting metadata fields: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to delete metadata fields: {str(e)}")

@app.post("/api/extract-debug")
async def extract_debug(request: Request):
    """Debug endpoint to see what's being sent"""
    try:
        print(f"=== DEBUG ENDPOINT ===")
        print(f"Method: {request.method}")
        print(f"Headers: {dict(request.headers)}")
        
        try:
            form = await request.form()
            print(f"Form data keys: {list(form.keys())}")
            for key, value in form.items():
                if hasattr(value, 'filename'):
                    print(f"File field '{key}': {value.filename}")
                else:
                    print(f"Form field '{key}': {str(value)[:100]}...")
        except Exception as form_error:
            print(f"Error parsing form: {form_error}")
            
        print(f"=== END DEBUG ===")
        return {"status": "debug complete", "message": "Check server logs"}
        
    except Exception as e:
        print(f"Debug endpoint error: {e}")
        return {"error": str(e)}

@app.post("/api/extract")
async def extract_files_api(request: Request):
    """
    🚀 OPTIMIZED: Handle file upload for metadata extraction with dual instance processing
    Enhanced with 200 concurrent requests (100 per instance) for 14k+ row datasets
    """
    try:
        print(f"=== OPTIMIZED EXTRACT ENDPOINT ===")
        
        # Parse form data
        form = await request.form()
        files = []
        metadata = ""
        
        for key, value in form.items():
            if hasattr(value, 'filename') and value.filename:
                files.append(value)
            elif key == "metadata":
                metadata = str(value)
        
        # Validate inputs
        if not files:
            raise HTTPException(status_code=400, detail="No files provided")
        if not metadata:
            raise HTTPException(status_code=400, detail="No metadata provided")
        
        start_time = datetime.now()
        print(f"🚀 OPTIMIZED PROCESSING started at: {start_time}")
        
        # Parse metadata
        metadata_obj = json.loads(metadata)
        
        # Extract fields configuration
        if "fieldsData" in metadata_obj and isinstance(metadata_obj["fieldsData"], dict):
            fields_data = metadata_obj["fieldsData"]
            meta_data_fields = fields_data.get("metaDataFields", [])
            free_text_desc = fields_data.get("freeTextDesc", "")
            free_text_col_name = fields_data.get("freeTextColName", "")
        elif "metaDataFields" in metadata_obj:
            meta_data_fields = metadata_obj.get("metaDataFields", [])
            free_text_desc = metadata_obj.get("freeTextDesc", "")
            free_text_col_name = metadata_obj.get("freeTextColName", "")
        else:
            meta_data_fields = metadata_obj.get("metaDataFields", []) or metadata_obj.get("metadataFields", [])
            free_text_desc = metadata_obj.get("freeTextDesc", "") or metadata_obj.get("freetextDescription", "")
            free_text_col_name = metadata_obj.get("freeTextColName", "") or metadata_obj.get("freeTextColumn", "")
        
        # Create MetadataField objects
        ai_fields = []
        for field in meta_data_fields:
            field_name = field.get("name", "").strip()
            if field_name and field_name.upper() != free_text_col_name.upper():
                ai_field = MetadataField(
                    name=field_name,
                    description=field.get("desc", ""),
                    isClassification=field.get("classify", False),
                    classificationOptions=None
                )
                ai_fields.append(ai_field)
        
        print(f"Processing {len(ai_fields)} fields: {[f.name for f in ai_fields]}")
        
        # Create examples (simplified)
        examples = []
        
        extracted_results = []
        
        # Process each uploaded file
        for file in files:
            df = None
            
            # Read file based on type
            if file.filename.endswith('.csv'):
                content = await file.read()
                try:
                    csv_content = content.decode('utf-8')
                except UnicodeDecodeError:
                    csv_content = content.decode('utf-8', errors='ignore')
                
                try:
                    df = pd.read_csv(StringIO(csv_content))
                except Exception as e:
                    raise HTTPException(status_code=400, detail=f"Unable to parse CSV: {str(e)}")
            
            elif file.filename.endswith(('.xlsx', '.xls')):
                content = await file.read()
                try:
                    excel_buffer = BytesIO(content)
                    df = pd.read_excel(excel_buffer)
                except Exception as e:
                    raise HTTPException(status_code=400, detail=f"Unable to parse Excel: {str(e)}")
            
            if df is None or len(df) == 0:
                continue
            
            # Find text column
            text_column = None
            if free_text_col_name and free_text_col_name in df.columns:
                text_column = free_text_col_name
            else:
                for col in df.columns:
                    if df[col].dtype == 'object':
                        text_column = col
                        break
            
            if text_column is None:
                continue
            
            # Apply row limit
            original_row_count = len(df)
            if len(df) > MAX_ROWS_LIMIT:
                print(f"Limiting to first {MAX_ROWS_LIMIT} rows")
                df = df.head(MAX_ROWS_LIMIT)
            
            print(f"🚀 Processing {len(df)} rows (original: {original_row_count})")
            
            # Set up optimization strategy
            instance_strategy = determine_instance_strategy(len(df))
            active_client_pool = setup_client_pool_for_strategy(instance_strategy)
            batch_settings = get_optimal_batch_settings(instance_strategy)
            
            # Process rows
            row_texts = []
            for idx, row in df.iterrows():
                text = str(row[text_column]).strip()
                if text and text.lower() not in ['nan', 'none', '']:
                    row_texts.append(text)
            
            if not row_texts:
                continue
            
            print(f"🚀 Processing {len(row_texts)} valid text rows")
            print(f"📊 Using {batch_settings['description']}")
            
            # Process in batches
            ai_results_list = []
            concurrent_limit = batch_settings["concurrent_limit"]
            batch_size = batch_settings["batch_size"]
            
            semaphore = asyncio.Semaphore(concurrent_limit)
            
            async def process_text_optimized(text: str, row_index: int):
                async with semaphore:
                    try:
                        return await extract_metadata_for_text_with_retry(
                            text, ai_fields, free_text_desc, examples=examples, row_index=row_index
                        )
                    except Exception as e:
                        print(f"Error processing row {row_index}: {str(e)}")
                        # Return error result
                        error_result = {}
                        for field in ai_fields:
                            error_result[field.name] = MetadataFieldResult(
                                value="Error",
                                confidence="Low",
                                reason=f"Processing error: {str(e)}"
                            )
                        return error_result
            
            # Process in batches
            total_batches = (len(row_texts) + batch_size - 1) // batch_size
            
            for batch_start in range(0, len(row_texts), batch_size):
                batch_end = min(batch_start + batch_size, len(row_texts))
                batch_texts = row_texts[batch_start:batch_end]
                batch_num = (batch_start // batch_size) + 1
                
                print(f"📦 Batch {batch_num}/{total_batches}: rows {batch_start}-{batch_end-1}")
                
                # Create batch tasks
                batch_tasks = []
                for i, text in enumerate(batch_texts):
                    row_index = batch_start + i
                    task = process_text_optimized(text, row_index)
                    batch_tasks.append(task)
                
                # Process batch with timeout
                batch_timeout = batch_settings["timeout_base"] + (len(batch_tasks) * batch_settings["timeout_per_row"])
                
                try:
                    batch_start_time = time.time()
                    batch_results = await asyncio.wait_for(
                        asyncio.gather(*batch_tasks, return_exceptions=True),
                        timeout=batch_timeout
                    )
                    batch_duration = time.time() - batch_start_time
                    
                    # Process results
                    for result in batch_results:
                        if isinstance(result, Exception):
                            # Create error result
                            error_result = {}
                            for field in ai_fields:
                                error_result[field.name] = MetadataFieldResult(
                                    value="Error",
                                    confidence="Low",
                                    reason=f"Batch error: {str(result)}"
                                )
                            ai_results_list.append(error_result)
                        else:
                            ai_results_list.append(result)
                    
                    throughput = len(batch_tasks) / batch_duration if batch_duration > 0 else 0
                    print(f"✅ Batch {batch_num} completed: {throughput:.1f} rows/second")
                    
                except asyncio.TimeoutError:
                    print(f"⏰ Batch {batch_num} timeout")
                    # Create timeout results
                    for _ in batch_texts:
                        timeout_result = {}
                        for field in ai_fields:
                            timeout_result[field.name] = MetadataFieldResult(
                                value="Error",
                                confidence="Low",
                                reason="Batch timeout"
                            )
                        ai_results_list.append(timeout_result)
                
                # Small delay between batches
                if batch_start + batch_size < len(row_texts):
                    await asyncio.sleep(batch_settings["delay_between_batches"])
            
            # Combine results
            for idx, (text, ai_results) in enumerate(zip(row_texts, ai_results_list)):
                extracted_metadata = {}
                
                for field_name, field_result in ai_results.items():
                    # Skip if identical to input or too long
                    if (field_result.value.strip() == text.strip() or 
                        len(field_result.value) > 150):
                        continue
                    
                    extracted_metadata[field_name] = {
                        "value": field_result.value,
                        "confidence": field_result.confidence,
                        "reason": field_result.reason
                    }
                
                result = {
                    "rowIndex": idx,
                    "originalText": text,
                    "extractedMetadata": extracted_metadata
                }
                extracted_results.append(result)
        
        # Generate feedback
        feedback = None
        if extracted_results:
            feedback_results = []
            for result in extracted_results:
                metadata_dict = {}
                for field_name, field_data in result.get("extractedMetadata", {}).items():
                    metadata_dict[field_name] = MetadataFieldResult(
                        value=field_data.get("value", ""),
                        confidence=field_data.get("confidence", "Medium"),
                        reason=field_data.get("reason", "")
                    )
                
                if metadata_dict:
                    feedback_result = MetadataExtractionResult(
                        rowIndex=result.get("rowIndex", len(feedback_results)),
                        originalText=result.get("originalText", ""),
                        extractedMetadata=metadata_dict
                    )
                    feedback_results.append(feedback_result)
            
            if feedback_results:
                try:
                    feedback = await generate_feedback_summary(feedback_results, ai_fields)
                except Exception as e:
                    print(f"Warning: Could not generate feedback: {str(e)}")
                    feedback = None
        
        # Save results (simplified for now)
        end_time = datetime.now()
        duration = end_time - start_time
        
        print(f"🎉 OPTIMIZED PROCESSING COMPLETED!")
        print(f"Total time: {duration}")
        print(f"Results: {len(extracted_results)}")
        
        response = {
            "results": extracted_results,
            "feedback": feedback,
            "optimizationInfo": {
                "processingTime": duration.total_seconds(),
                "throughput": len(extracted_results) / duration.total_seconds() if duration.total_seconds() > 0 else 0,
                "optimizedProcessing": True
            }
        }
        
        # Add row limit info if applicable
        if 'original_row_count' in locals() and original_row_count > MAX_ROWS_LIMIT:
            response["rowLimitInfo"] = {
                "originalRowCount": original_row_count,
                "processedRowCount": len(extracted_results),
                "wasLimited": True,
                "limit": MAX_ROWS_LIMIT,
                "message": f"Input file had {original_row_count} rows. Only the first {MAX_ROWS_LIMIT} rows were processed due to system limits."
            }
        
        return response
        
    except json.JSONDecodeError as e:
        print(f"JSON parsing error: {str(e)}")
        raise HTTPException(status_code=400, detail=f"Invalid metadata JSON: {str(e)}")
    except Exception as e:
        print(f"Error in extract_files_api: {str(e)}")
        print(f"Full traceback: {traceback.format_exc()}")
        raise HTTPException(status_code=500, detail=f"Error processing files: {str(e)}")

@app.get("/", include_in_schema=False)
async def root():
    return RedirectResponse(url="/index.html")

app.mount("/", StaticFiles(directory="static"), name="static")

if __name__ == "__main__":
    log.info("ChatENB WorkSmart AI WebApp Starting Up...")
    uvicorn.run(app, host="0.0.0.0", port=8000)